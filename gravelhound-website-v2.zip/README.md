# Gravel Hound Adventures — V2 Prototype

Open `index.html` to view the new prototype.

Pages:
- `index.html` — full magazine-style homepage
- `routes.html` — route / GPX library
- `route.html` — individual adventure route page
- `article.html` — Tenere Tales article template

This prototype uses original vector artwork so it works without copying third-party photography. The next design pass can replace these illustrations with genuine Gravel Hound ride photos.
